Make sure to unzip and install libraries /extra_libraries
to either

/Users/yourname/Documents/Processing/libraries
on your personal computer

or
/Users/Shared/Documents/Processing/libraries
on the school computers


Also checkout Matthew Epler's videos at
https://vimeo.com/album/2573675
