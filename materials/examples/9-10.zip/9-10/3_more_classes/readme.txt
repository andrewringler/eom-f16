Adapted from Ginnie S. Hsu's assignment #1 2015
