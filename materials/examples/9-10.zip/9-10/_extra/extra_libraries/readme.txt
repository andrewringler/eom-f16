In order for many of these sketches to run you must install some libraries for Processing by doing the following:
	Copy each of the folders located in extra_libraries into the following directory on your computer
	Documents/Processing/libraries


On the school computers this folder is actually

Users/Shared/Documents/Processing/libraries