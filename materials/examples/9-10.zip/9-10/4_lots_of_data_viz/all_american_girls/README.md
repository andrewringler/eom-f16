"All American Girls" is a series of cross-stitch pieces that represent the female vote in particular states during the 2012 Presidential Election.  This source code generates the patterns used to hand-stitch the pieces in November and December 2012.

To use, select a state from the "turnout.csv" file, and load it into the "final_FINAL" project.  Scale the resulting png up in Illustrator and save the file, then load it into the "final_GRID" sketch.  The result from "final_GRID" will be the pattern that you can use.

You can also download 11 completed patterns here: http://rouxpz.com/s/aag_patterns.pdf

This project is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported.  For more information, please visit http://creativecommons.org/licenses/by-nc-sa/3.0/