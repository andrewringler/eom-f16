David Hunter
http://davidhunterdesign.com/

- ProcessingTutorials
	https://github.com/DHDPIC/ProcessingTutorials

	CREATIVE CODING 2013
	Education Programme
	Creative Code 2013 was a six week extra-curricular course to introduce programming to Graphic Design students at Ravensbourne College. Using Processing, the basics of programming were covered and then students were encouraged to explore further and tackle a brief or integrate creative coding into their own projects.

