**Alvin**

***or***

***Art from the Bottom of the Ocean***

This is the code repository for my work as artist-in-residency-at-sea on the R/V Atlantis, in May/June 2014.

I'll be posting results of sketches & explorations here, as well as data where filesize and ownership permit.

As a lot of this work is being made on the fly, don't expect things to be too tidy! Pull requests for clean-ups and optimizations are welcome.

Most code is written in [Processing] (http://processing.org). 

Jer Thorp

@blprnt

http://blog.blprnt.com
