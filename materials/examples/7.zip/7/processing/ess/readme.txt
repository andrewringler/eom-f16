Examples from Processing Handbook ed. 1

copy 
ess folder (in libraries)
into your Documents / Processing / libraries folder

re: http://www.tree-axis.com/Ess/download.html
