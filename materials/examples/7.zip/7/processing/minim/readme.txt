Selection of examples from the
minim project examples directory
http://code.compartmental.net/minim/

See your Documents/Processing/libraries/minim/examples for additional examples
