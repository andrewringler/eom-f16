Examples from
Coursera - Creative Programming for Digital Media & Mobile Apps 
