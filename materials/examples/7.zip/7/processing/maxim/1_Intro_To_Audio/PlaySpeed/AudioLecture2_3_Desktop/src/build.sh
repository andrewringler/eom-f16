javac -cp .:core.jar -d build MaximJavaTest.java
java -cp ./build/:core.jar MaximJavaTest
