http://www.looperman.com/loops/detail/64279
http://www.looperman.com/loops/detail/56877
http://www.looperman.com/loops/detail/52023
http://www.looperman.com/loops/detail/63065
http://www.looperman.com/loops/detail/57452
http://www.looperman.com/loops/detail/52314
http://www.looperman.com/loops/detail/40024