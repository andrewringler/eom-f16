Processing, make sure to install the following libraries to use the examples:
- Video
- OpenCV for Processing

From Processing Menu
Sketch > Import Library… > Add Library…	
then search for library by name, click it, then click Install

The flog examples use the flob library
http://s373.net/code/flob/, which does not need to be installed
since I have added a "code" directory to each example with the library
