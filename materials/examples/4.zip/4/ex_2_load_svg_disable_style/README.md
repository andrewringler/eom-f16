https://github.com/processing/processing-docs/tree/master/content/examples/Basics/Shape/DisableStyle
